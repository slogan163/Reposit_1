package updateServlets;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by Пользователь on 05.04.2015.
 */
public class UpdateStudentServlet extends HttpServlet
{
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
        String stud_id = req.getParameter("stud_id");
        String fname = req.getParameter("fname");
        String lname = req.getParameter("lname");
        String st_group_id = req.getParameter("st_group_id");

        req.setAttribute("stud_id", stud_id);
        req.setAttribute("fname", fname);
        req.setAttribute("lname", lname);
        req.setAttribute("st_group_id", st_group_id);

        req.getRequestDispatcher("/updatePages/updateStudentPage.jsp").forward(req, resp);
    }
}
