package com.devcolibri.servlet.xmlServlet;

import com.devcolibri.bean.StudentBean;
import com.devcolibri.entity.Student;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

@WebServlet("/writeStudentServlet")
public class WriteStudentServlet extends HttpServlet
{
    @EJB
    StudentBean studentBean;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
        List<Student> students = (List<Student>) req.getSession().getAttribute("students");
        String xml = studentBean.writeXML(students);

        //изменияем контекст
        String fileName = req.getParameter("file_name")+ ".xml";
        String header = "attachment;filename=" + fileName;
        resp.setContentType("application/octet-stream");
        resp.setHeader("Content-Disposition", header);

        ServletOutputStream out = resp.getOutputStream();

        //пишем файл
        byte[] outputByte = xml.getBytes();
        //copy binary contect to output stream
        for(int i=0; i< outputByte.length; i++)
        {
            out.write(outputByte[i]);
        }
        out.flush();
        out.close();

        //и возвращаем кодировку
        resp.setContentType("text/html; charset=windows-1251");
        req.getRequestDispatcher("/entryPage/groupPage.jsp").forward(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
        super.doGet(req, resp);
    }
}
