package com.devcolibri.bean;

import com.devcolibri.entity.Group;
import com.thoughtworks.xstream.XStream;
import org.xml.sax.SAXException;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import java.io.*;
import java.util.ArrayList;
import java.util.List;


@Stateless
@Local
public class GroupBean
{
    @PersistenceContext(unitName = "DEVMODE")
    private EntityManager em;

    public Group add(Group group)
    {
        return em.merge(group);
    }

    public Group get(int id)
    {
        return em.find(Group.class, id);
    }

    public void update(Group group){
        add(group);
    }

    public void delete(int id){
        em.remove(get(id));
    }

    public List<Group> getAll(){
        TypedQuery<Group> namedQuery = (TypedQuery<Group>) em.createQuery("select g from group_students g");
        return namedQuery.getResultList();
    }

    public List<Group> getAll(String name, String course)
    {
        String sql = getSQL(name, course);
        System.out.println(sql);
        return em.createQuery(sql).getResultList();

    }

    private String getSQL(String groupName, String course)
    {
        StringBuilder sql = new StringBuilder("Select g from group_students g");
        List<String> attributes = new ArrayList<String>();

        if(!groupName.equals(""))
            attributes.add("group_name = '" + groupName+"'");
        if(!course.equals(""))
            attributes.add("course = " + course);

        for(int i = 0; i < attributes.size(); i++)
        {
            if(i == 0)
            {
                sql.append(" where ").append(attributes.get(i));
            }
            else
            {
                sql.append(" AND ").append(attributes.get(i));
            }
        }

        return sql.toString();
    }

    public String writeXML(List<Group> groups)
    {
        XStream xStream = new XStream();
        xStream.alias("GroupList", List.class);
        xStream.alias("Group", Group.class);
        return xStream.toXML(groups);
    }

    public void readXML(File file)
    {
        XStream xStream =new XStream();
        xStream.alias("GroupList", List.class);
        xStream.alias("Group", Group.class);
        xStream.aliasField("ID",Group.class,"id");
        xStream.aliasField("Name",Group.class,"name");
        xStream.aliasField("Course",Group.class,"course");

        List<Group> groups = (List<Group>) xStream.fromXML(file);

        for(Group group : groups)
        {
            update(group);
        }
    }

    public boolean validXML(File xml) throws IOException
    {
        boolean success = false;
        SchemaFactory factory = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
        File schemaLocation = new File("C:\\Users\\Пользователь\\IdeaProjects\\TestWildFly\\shema_group.xml");

        try
        {
            Schema schema = factory.newSchema(schemaLocation);
            Validator validator = schema.newValidator();
            Source source = new StreamSource(xml);
            validator.validate(source);
            success = true;
        }
        catch (SAXException ex)
        {
            ex.printStackTrace();
            success = false;
        }
        finally
        {
            return success;
        }
    }

}
