package com.devcolibri.bean;

import com.devcolibri.entity.Group;
import com.devcolibri.entity.Student;
import com.thoughtworks.xstream.XStream;
import org.xml.sax.SAXException;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

@Stateless
@Local
public class StudentBean
{
    @PersistenceContext(unitName = "DEVMODE")
    private EntityManager em;

    //добавить студента
    public Student add(Student student){
        return em.merge(student);
    }

    //Получить студента по ИД
    public Student get(int id){
        return em.find(Student.class, id);
    }

    // если Student которого мыпытаемся обновить нет,
    // то запишется он как новый
    public void update(Student student){
        add(student);
    }

    // удаляем студента по id
    public void delete(int id){
        em.remove(get(id));
    }

    // Получаем всех студентов с БД
    public List<Student> getAll(){
        TypedQuery<Student> namedQuery = (TypedQuery<Student>) em.createQuery("select s from student s");
        return namedQuery.getResultList();
    }

    public List<Student> getAll(String fname, String lname, String groupName)
    {
        String sql = getSQL(fname, lname, groupName);
        System.err.println(sql);
        return em.createQuery(sql).getResultList();
    }

    public List<Student> getGroup(int groupID)
    {
        return em.createQuery("select s from student s where s.groupID = :custGroupID").setParameter("custGroupID", groupID).getResultList();
    }

    private String getSQL(String fname, String lname, String groupName)
    {
        StringBuilder sql = new StringBuilder("select s from student s");
        List<String> attributes = new ArrayList<String>();

        if(!fname.equals(""))
            attributes.add("first_name = '" + fname +"'");
        if(!lname.equals(""))
            attributes.add("last_name = '" + lname +"'");
        if(!groupName.equals(""))
            attributes.add("st_group_id IN (SELECT g FROM group_students g WHERE group_name = '" + groupName + "')");

        for(int i = 0; i < attributes.size(); i++)
        {
            if(i == 0)
            {
                sql.append(" where " + attributes.get(i));
            }
            else
            {
                sql.append(" AND " + attributes.get(i));
            }
        }

        return sql.toString();

    }

    public String writeXML(List<Student> students)
    {
        XStream xStream = new XStream();
        xStream.alias("StudentList", List.class);
        xStream.alias("Student", Student.class);
        return xStream.toXML(students);
    }

    public void readXML(File file)
    {
        XStream xStream =new XStream();
        xStream.alias("StudentList", List.class);
        xStream.alias("Student", Student.class);
        xStream.aliasField("ID",Student.class,"id");
        xStream.aliasField("Name",Student.class,"name");
        xStream.aliasField("LastName",Student.class,"lastName");
        xStream.aliasField("GroupID",Student.class,"groupID");

        List<Student> students = (List<Student>) xStream.fromXML(file);

        for(Student student : students)
        {
            update(student);
        }
    }

    public boolean validXML(File xml)
    {
        boolean success = false;
        SchemaFactory factory = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
        File schemaLocation = new File("C:\\Users\\Пользователь\\IdeaProjects\\TestWildFly\\shema_student.xml");

        try
        {
            Schema schema = factory.newSchema(schemaLocation);
            Validator validator = schema.newValidator();
            Source source = new StreamSource(xml);
            validator.validate(source);
            success = true;
        }
        catch (SAXException ex)
        {
            ex.printStackTrace();
            success = false;
        }
        finally
        {
            return success;
        }
    }
}
