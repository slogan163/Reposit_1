package com.devcolibri.entity;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import javax.persistence.*;

@Entity(name = "student")
@XStreamAlias("Student")
public class Student
{

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "student_id")
    @XStreamAlias("ID")
    private int id;

    @Column(name = "first_name", nullable = false)
    @XStreamAlias("Name")
    private String name;

    @Column(name = "last_name", nullable = false)
    @XStreamAlias("LastName")
    private String lastName;

    @Column(name = "st_group_id", nullable = false)
    @XStreamAlias("GroupID")
    private int groupID;

    public Student() {
    }

    public Student(String name, String lastName, int groupID)
    {
        this.name = name;
        this.lastName = lastName;
        this.groupID = groupID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getGroupID()
    {
        return groupID;
    }

    public void setGroupID(int groupID)
    {
        this.groupID = groupID;
    }
}
