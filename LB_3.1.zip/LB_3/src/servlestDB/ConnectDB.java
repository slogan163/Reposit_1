package servlestDB;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

/**
 * Created by Пользователь on 26.03.2015.
 */
public class ConnectDB
{
    private static volatile ConnectDB instance;
    private Connection connection;

    public static ConnectDB instance()
    {
        ConnectDB localInstance = instance;
        if (localInstance == null)
        {
            synchronized (ConnectDB.class)
            {
                localInstance = instance;
                if (localInstance == null)
                {
                    instance = localInstance = new ConnectDB();
                }
            }
        }
        return localInstance;
    }

    public void init(String login, String password) throws SQLException
    {
        String driverName = "oracle.jdbc.driver.OracleDriver";
        String urlDB = "jdbc:oracle:thin:@//localhost:1521/xe";
        Locale.setDefault(Locale.US);

        try
        {
            Class.forName(driverName);
            connection = DriverManager.getConnection(urlDB, login, password);
        }
        catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }
    }

    public void close()
    {
        try
        {
            connection.close();
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }

    public List<Group> allGroupRow()
    {
        String sql = "SELECT * FROM GROUP_STUDENTS";
        return answerGroup(sql);
    }

    public List<Group> searchInGroup(String atribute, String value)
    {
        String sql = "Select * From GROUP_STUDENTS " +
                        "Where " + atribute + " = " + value;

        return answerGroup(sql);
    }

    public List<Group> searchInGroup(HashMap<String, String> parameters)
    {
        String sqlBegin = "Select * From GROUP_STUDENTS Where ";
        String sql = addConditions(sqlBegin, parameters);
        return answerGroup(sql);
    }

    public List<Student> allStudentRow()
    {
        String sql = "Select * From STUDENTS";
        return answerStudent(sql);
    }

    public List<Student> searchInStudent(String atribute, String value)
    {
        String sql = "Select * From STUDENTS " +
                "Where " + atribute + " = " + value;

        return answerStudent(sql);
    }

    public List<Student> searchInStudent(HashMap<String, String> parameters)
    {
        String sqlBegin = "Select * From STUDENTS Where ";
        String sql = addConditions(sqlBegin, parameters);
        return answerStudent(sql);
    }

    private String addConditions(String sqlBegin, HashMap<String, String> parameters)
    {
        StringBuilder sql = new StringBuilder(sqlBegin);
        int iterator = 0;

        for(HashMap.Entry<String, String> entry : parameters.entrySet())
        {
            if(iterator != 0)
                sql.append(" AND");
            iterator++;
            String parameter = entry.getKey();
            String value = entry.getValue();
            sql.append(" " + parameter + " = " + value);
        }

        return sql.toString();
    }

    private List<Group> answerGroup(String sql)
    {
        List<Group> groups = null;
        try
        {
            Statement statement = connection.createStatement();
            System.out.println("SQL: " + sql);

            ResultSet resultSet = statement.executeQuery(sql);
            groups = new ArrayList<Group>();

            while (resultSet.next())
            {
                int group_id = resultSet.getInt("group_id");
                String group_name = resultSet.getString("group_name");
                int head_id = resultSet.getInt("head_id");

                Group group = new Group(group_id,group_name,head_id);
                groups.add(group);

                System.out.println("Result DB: " + group_id + " " + group_name + " " + head_id);
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        finally
        {
            return groups;
        }
    }

   private List<Student> answerStudent(String sql)
   {
       List<Student> students = null;

       try
       {
           Statement statement = connection.createStatement();
           System.out.println("SQL: " + sql);

           ResultSet resultSet = statement.executeQuery(sql);

           students = new ArrayList<Student>();

           while (resultSet.next())
           {
               int stud_id = resultSet.getInt("stud_id");
               String fname = resultSet.getString("fname");
               String lname = resultSet.getString("lname");
               int st_group_id = resultSet.getInt("st_group_id");

               Student student = new Student(stud_id, fname, lname, st_group_id);
               students.add(student);

               System.out.println("Result DB: " + stud_id + " "+ fname +" "+ lname +" "+ st_group_id);
           }
       }
       catch (SQLException e)
       {
           e.printStackTrace();
       }
       finally
       {
           return students;
       }
   }

    public void updateGroup(String group_id, String group_name, String head_id) throws SQLException
    {
        String sql = "Update GROUP_STUDENTS SET  group_name = " +
                group_name + ", head_id = " + head_id +
                " Where group_id = " + group_id;
        System.out.println(sql);

        Statement statement = connection.createStatement();
        statement.executeUpdate(sql);

    }
    public void updateStudent(String stud_id, String fname, String lname, String st_group_id) throws SQLException
    {
        String sql = "Update STUDENTS SET  fname = " + fname + ", fname = " + fname +
                ", lname = " + lname +
                " Where stud_id = " + stud_id;

        System.out.println(sql);
        Statement statement = connection.createStatement();
        statement.executeUpdate(sql);

    }

}
