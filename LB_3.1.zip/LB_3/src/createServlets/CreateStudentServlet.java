package createServlets;

import javax.servlet.http.HttpServlet;

/**
 * Created by Пользователь on 04.04.2015.
 */
public class CreateStudentServlet extends HttpServlet
{
}
