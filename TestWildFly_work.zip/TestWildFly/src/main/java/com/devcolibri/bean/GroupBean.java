package com.devcolibri.bean;

import com.devcolibri.entity.Group;
import com.devcolibri.entity.Student;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.util.ArrayList;
import java.util.List;


@Stateless
@Local
public class GroupBean
{
    @PersistenceContext(unitName = "DEVMODE")
    private EntityManager em;

    public Group add(Group group)
    {
        return em.merge(group);
    }

    public Group get(int id)
    {
        return em.find(Group.class, id);
    }

    public void update(Group group){
        add(group);
    }

    public void delete(int id){
        em.remove(get(id));
    }

    public List<Group> getAll(){
        TypedQuery<Group> namedQuery = (TypedQuery<Group>) em.createQuery("select g from group_students g");
        return namedQuery.getResultList();
    }

    public List<Group> getAll(String name, String course)
    {
        String sql = getSQL(name, course);
        System.out.println(sql);
        return em.createQuery(sql).getResultList();

    }

    private String getSQL(String groupName, String course)
    {
        StringBuilder sql = new StringBuilder("Select g from group_students g");
        List<String> attributes = new ArrayList<String>();

        if(!groupName.equals(""))
            attributes.add("group_name = '" + groupName+"'");
        if(!course.equals(""))
            attributes.add("course = " + course);

        for(int i = 0; i < attributes.size(); i++)
        {
            if(i == 0)
            {
                sql.append(" where " + attributes.get(i));
            }
            else
            {
                sql.append(" AND " + attributes.get(i));
            }
        }

        return sql.toString();
    }
}
